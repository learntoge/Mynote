[返回首页](../index.html)

# JavaWeb学习笔记——***By Bug***

## 前言

本笔记是Javaweb开发的笔记，需要有一定的前端基础和Java基础
笔记中省略了HTML，CSS，JavaScript，Vue，Ajax相关知识，主要记录的是Java相关内容

说明：
	本笔记为本人学习过程中随手写的笔记，为复习使用，笔记中可能存在遗漏或错误，具体请以官方文档和权威书籍为准！谢谢！
	笔记中的一些图片等元素因路径配置问题，可能会发生丢失。
	笔记中展示的构造器和方法等的知识点仅为部分内容，完整内容请查阅官方开发文档内容！



## 参考资料

【黑马程序员JavaWeb开发教程，实现javaweb企业开发全流程（涵盖Spring+MyBatis+SpringMVC+SpringBoot等）】 https://www.bilibili.com/video/BV1m84y1w7Tb/?share_source=copy_web&vd_source=ea0cf64e8dac6f0193a7e28187a0fccb



## Web开发简介

什么是Web？
Web即全球广域网，也称万维网，能够通过浏览器访问到的网站

![image-20240808182726472](./imgs/image-20240808182726472.png)

![image-20240808182802007](./imgs/image-20240808182802007.png)



## Axios

Axios是对原生的Ajax进行了封装，简化书写

Axios官方文档👇
[起步 | Axios中文文档 | Axios中文网 (axios-http.cn)](https://www.axios-http.cn/docs/intro)



## 前端工程化

Vue2+Vue3笔记

当前主流开发模式：前后端分离模式
前端开发前端页面，后端开发后端程序，前端使用数据时使用API获得相应的数据
以接口文档为标准


流程：需求分析→定义接口文档→前后端并行开发（遵循API文档）→测试（前后端分别测试）→前后端联调测试

接口文档管理平台推荐：YApi，POSTMAN，APIFox

前端工程化开发：模块化（js,css），组件化（UI结构，样式，行为），规范化（结构，编码，接口），自动化（构建，部署，测试）

Element





































