[返回首页](../index.html)

# Nginx教程——***By Bug***

## 参考资料

https://www.bilibili.com/video/BV1ov41187bq

## Nginx介绍

### 背景介绍

Nginxs是一个具有高性能的【HTTP】和【反向代理】的【web服务器】，同时也是一个【POP3/SMTP/IMAP代理服务器】，是 Igor Sysoev使用C语言编写的

Web服务器

- **静态 web 服务器**（static web server）由一个计算机（硬件）和一个 HTTP 服务器（软件）组成。我们称它为“静态”是因为这个服务器把它托管文件的“保持原样”地传送到你的浏览器。

- **动态 web 服务器**（dynamic web server）由一个静态的网络服务器加上额外的软件组成，最普遍的是一个*应用服务器*和一个*数据库*。我们称它为“动态”是因为这个应用服务器会在通过 HTTP 服务器把托管文件传送到你的浏览器之前会对这些托管文件进行更新。

HTTP

- **HTTP** 是一种用作获取诸如 HTML 文档这类资源的[协议](https://developer.mozilla.org/zh-CN/docs/Glossary/Protocol)。它是 Web 上进行任何数据交换的基础，同时，也是一种客户端—服务器（client-server）协议，也就是说，请求是由接受方——通常是 Web 浏览器——发起的。完整网页文档通常由文本、布局描述、图片、视频、脚本等资源构成。

POP3/SMTP/IMAP代理服务器

- **POP3**是Post Office Protocol 3的简称，即邮局协议的第3个版本,它规定怎样将个人计算机连接到Internet的邮件服务器和下载电子邮件的电子协议。它是因特网电子邮件的第一个离线协议标准,POP3允许客户从服务器上把邮件存储到本地主机（即自己的计算机）上,同时删除保存在邮件服务器上的邮件，而POP3服务器则是遵循POP3协议的接收邮件服务器，用来接收电子邮件的。

- **IMAP**全称是Internet Mail Access Protocol（交互式邮件存取协议），与POP3一样都是一种邮件获取协议。它的主要作用是邮件客户端（例如iPhone、Foxmail）可以通过这种协议从邮件服务器上获取邮件的信息，下载邮件等。IMAP的功能是各处同步，即在网页、客户端、手持设备上对邮箱的操作，均多向同步。如果一封在网页中打开过的新邮件，在iPad上登录邮箱后，该邮件也是已读状态；一封邮件在iPhone上被彻底删除，在Foxmail登录邮箱后，将找不到该邮件。

- **SMTP** 的全称是“Simple Mail Transfer Protocol”，即简单邮件传输协议。它是一组用于从源地址到目的地址传输邮件的规范，通过它来控制邮件的中转方式。SMTP 协议属于 TCP/IP 协议簇，它帮助每台计算机在发送或中转信件时找到下一个目的地。SMTP 服务器就是遵循 SMTP 协议的发送邮件服务器。



### Nginx的优点

1. 速度快，并发更高
   单次请求或高并发请求的环境下，nginx都会比其他web服务器相应的速度更加快。
2. 配置简单，扩展性强
   Nginx极具扩展性，它本身就是由很多个模块构成的，这些模块的使用可以通过配置文件的配置来进行添加。这些模块由官方或第三方提供。如有需要，完全可以开发自己业务需要的模块
3. 高可靠性
   Nginx采用的是多线程模式运行，其中有一个master主进程和N个worker进程，worker的数量可以手动设置，每个worker之间都是独立提供服务的，master可以在一个worker运行出错时，快速拉起新的worker进程提供服务
4. 热部署
   互联网项目要求7*24小时进行服务提供，Nginx提供了热部署功能，在不停止Nginx的情况下，对Nginx进行文件升级，更新配置，更改日志等操作
5. 成本低，BSD许可证
   BSD是一个开源的许可证，世界上由许多开源许可证。
   目前较为流行的许可证：GPL，BSD，MIT，Mozilla，Apache，LGPL



### Nginx的功能和常用功能

Nginx提供的基本功能服务从大体上归纳为“基本HTTP服务”、“高级HTTP服务”和"邮件服务"等三大类。

- 基本HTTP服务
  Nginx可以提供基本HTTP服务，可以作为HTTP代理服务器和反向代理服务器，支持通过缓存加速访问，可以完成简单的负载均衡和容错，支持包过滤功能，支持SSL等。

  - 处理静态文件、处理索引文件以及支持自动索引；
  - 提供反向代理服务器，并可以使用缓存加上反向代理，同时完成负载均衡和容错；
  - 提供对FastCGI、memcached等服务的缓存机制，同时完成负载均衡和容错；
  - 使用Nginx的模块化特性提供过滤器功能。Nginx基本过滤器包括gzip压缩、ranges支持、chunked响应、XSLT、SSI以及图像缩放等。其中针对包含多个SSI的页面，经由FastCGI或反向代理，SSI过滤器可以并行处理。
  - 支持HTTP下的安全套接层安全协议SSL
  - 支持基于加权和依赖的优先权的HTTP/2高级HTTP服务

- 高级HTTP服务

  - 支持基于名字和IP的虚拟主机设置
  - 支持HTTP/1.0中的KEEP-Alive模式和管线(PipeLined)模型连接
  - 自定义访问日志格式、带缓存的日志写操作以及快速日志轮转。
  - 提供3xx～5xx错误代码重定向功能
  - 支持重写（Rewrite）模块扩展
  - 支持重新加载配置以及在线升级时无需中断正在处理的请求
  - 支持网络监控
  - 支持FLV和MP4流媒体传输

- 邮件服务

  Nginx提供邮件代理服务也是其基本开发需求之一，主要包含以下特性：

  - 支持IMPA/POP3代理服务功能

  - 支持内部SMTP代理服务功能

- 常用的功能模块

  - 静态资源部署
  - Rewrite地址重写——正则表达式
  - 反向代理
  - 负载均衡——轮询，加权轮询，ip_hash，url_hash、fair
  - web缓存
  - 环境部署——搭建高可用环境
  - 用户认证模块

- Nginx的核心组成

  - Nginx——二进制可执行文件
  - Nginx.conf——配置文件
  - error.log——错误的日志记录
  - access.log——访问日志记录



## Nginx环境准备

Nginx官网：https://nginx.org/

nginx文档：[nginx documentation](https://nginx.org/en/docs/)

准备linux系统

下载源码包（稳定版Stable version）



### Nginx安装

1. 通过源码安装

   准备工作
   GCC编译器

   ```
   yum install -y gcc //安装
   gcc --version //查看是否安装成功
   ```

   PCRE

   ```
   yum install -y pcre pcre-devel //安装
   rpm -qa pcre pcre-devel //查看是否安装成功
   ```

   zlib

   ```
   yum install -y zlib zlib-devel //安装
   rpm -qa zlib zlib-devel //查看是否安装成功
   ```

   OpenSSL

   ```
   yum install -y openssl openssl-devel //安装
   rpm -qa pcre openssl openssl-devel //查看是否安装成功
   ```

   ```
   yum install -y gcc pcre pcre-devel zlib zlib-devel openssl opensell-devel
   //一次全部安装
   ```

   源代码简单安装

   1. 下载源码

      ```
      wget https://nginx.org/download/nginx-1.26.1.tar.gz
      ```

   2. 解压缩

      ```
      tar -xzf nginx-1.26.1.tar.gz
      ```

   3. 进入资源文件进行简单配置

      ```
      ./configure
      ```

   4. 编译

      ```
      make
      ```

   5. 安装

      ```
      make install
      ```

      

   源代码复杂安装

   这种安装方式通过 ./configure 来对编译参数进行设置，需要我们进行手动指定

   PATH:是和路径相关的配置信息

   with:是启动模块，默认是关闭的

   without:是关闭模块，默认是开启的

   –prefix=PATH
   	指向Nginx的安装目录，默认值为/usr/local/nginx   

   

   –sbin-path=PATH
   	指向(执行)程序文件(nginx)的路径,默认值为\<prefix>/sbin/nginx

   

   –modules-path=PATH

   ​	指向Nginx动态模块安装目录，默认值为\<prefix>/modules

   

   –conf-path=PATH
   	指向配置文件(nginx.conf)的路径,默认值为\<prefix>/conf/nginx.conf

   

   –error-log-path=PATH
   	指向错误日志文件的路径,默认值为\<prefix>/logs/error.log

   

   –http-log-path=PATH
   	指向访问日志文件的路径,默认值为\<prefix>/logs/access.log

   

   –pid-path=PATH
   	指向Nginx启动后进行ID的文件路径，默认值为\<prefix>/logs/nginx.pid

   

   –lock-path=PATHcd

   ​	指向Nginx锁文件的存放路径,默认值为\<prefix>/logs/nginx.lock

   

2. 通过yum安装

   1. 安装yum-utils
   
      ```
      sudo yum install yum-utils
      ```
   
   2. 配置文件nginx.repo
   
      ```
      vim /etc/yum.repos.d/nginx.repo
      ```
   
      输入下面内容
   
      ```
      [nginx-stable]
      name=nginx stable repo
      baseurl=http://nginx.org/packages/centos/$releasever/$basearch/
      gpgcheck=1
      enabled=1
      gpgkey=https://nginx.org/keys/nginx_signing.key
      module_hotfixes=true
      
      [nginx-mainline]
      name=nginx mainline repo
      baseurl=http://nginx.org/packages/mainline/centos/$releasever/$basearch/
      gpgcheck=1
      enabled=0
      gpgkey=https://nginx.org/keys/nginx_signing.key
      module_hotfixes=true
      ```
   
   3. yum在线安装
   
      ```
      sudo yum install -y nginx
      ```
   
   4. 查找nginx安装位置
   
      ```
      whereis nginx
      ```
   



### nginx卸载

1. 关闭nginx进程

   ```
   ./nginx -s stop
   ```

2. 将nginx删除

   ```
   rm -rf /usr/local/nginx
   ```

3. 清除编译的环境

   ```
   make clean
   ```



### nginx启停

1. Nginx服务的信号控制

   ```
   //解除nginx列出当前系统中正在运行的进程信息。
   ps -ef | grep nginx
   //发送信号
   kill-QUIT '进程ID'
   ```

   信号

   | 信号     | 作用                                             |
   | :------- | ------------------------------------------------ |
   | TERM/INT | 立即关闭整个服务                                 |
   | QUIT     | 关闭整个服务（处理完当前请求后关闭）             |
   | HUP      | 重读配置文件并使用服务对新配置项生效             |
   | USR1     | 重新打开日志文件，可用来进行日志切割             |
   | USR2     | 平滑升级到最新的nginx                            |
   | WINCH    | 所有子进程不再接受处理新连接，相当于关闭work进程 |

   调用命令：kill -signal(信号) PID(进程id)

   

2. nginx的命令行控制
   通过nginx安装目录的sbin下的nginx控制

   ```
   相关设置
   Options:
   -?,-h         : this help    // 显示该帮助信息
   -v            : show version and exit      // 打印版本号并退出
   -V            : show version and configure options then exit  // 打印版本号和配置并退出
   -t            : test configuration and exit // 测试配置正确性并退出
   -T            : test configuration, dump it and exit  // 测试配置正确性，转储它并退出 ??
   -q            : suppress non-error messages during configuration testing  // 测试配置时只显示错误
   -s signal     : send signal to a master process: stop, quit, reopen, reload    // 向主进程发送信号
   -p prefix     : set prefix path (default: /Nginx/)    // 指定Nginx 服务器路径前缀
   -c filename   : set configuration file (default: conf/nginx.conf)    // 指定 Nginx 配置文件路径
   -g directives : set global directives out of configuration file    // 指定 Nginx 附加配置文件路径
   ```
   



### Nginx平滑升级

1. 使用Nginx服务信号进行版本升级

   1. 进入旧版本的Nginx目录，对Nginx可执行文件进行备份，防止升级失败，便于版本回退

      ```
      cd /usr/local/nginx/sbin
      mv nginx nginxold
      ```

   2. 切换到新版本目录，进行编译，将新版本编译后的objs下的nginx文件拷贝到原安装目录下的sbin目录中

      ```
      cp nginx /usr/local/nginx/sbin
      ```

   3. 发信号USR2给正在运行的旧版本Nginx的master进程

      ```
      kill -USR2 进程号
      ```

   4. 发信号QUIT给正在运行的旧版本Nginx的master进程

      ```
      kill -quit 旧进程号
      ```

2. 使用Nginx安装目录下的make命令进行升级

   1. 进入旧版本的Nginx目录，对Nginx可执行文件进行备份，防止升级失败，便于版本回退

   2. 切换到新版本目录，进行编译，将新版本编译后的objs下的nginx文件拷贝到原安装目录下的sbin目录中

   3. 进入安装目录，执行make upgrade

   4. 查看是否 

      ```
      ./nginx -v
      ```

      

## nginx.conf配置文件

### 默认的三大块

- 全局配置块
- events块
- http块
  一个http块中可以配置多个server块
  一个server块中又可以配置多个location块



### 全局块

#### user指令

user指令：用于配置运行Nginx服务器的worker进程的用户和用户组

| 语法   | user username [group] |
| ------ | --------------------- |
| 默认值 | nobody                |
| 位置   | 全局块                |

当访问权限不足时，网页会报403错误



#### 工作进程的两个指令

- master_process：用来指定是否开启工作进程

  | 语法   | master_process on/off |
  | ------ | --------------------- |
  | 默认值 | on                    |
  | 位置   | 全局块                |

- worker_orpcesses值设置与CPU内核数相同

  | 语法   | worker_orpcesses 数/auto (指定个数/自动) |
  | ------ | ---------------------------------------- |
  | 默认值 | 1                                        |
  | 位置   | 全局块                                   |

  

#### 其他配置指令 

- deamon  设置nginx是否以守护进程的方式启动

  | 语法   | deamon on/off |
  | ------ | ------------- |
  | 默认值 | on            |
  | 位置   | 全局块        |

- pid ：用来配置Nginx当前master进程的进程号id存储路径

  | 语法   | pid file路径               |
  | ------ | -------------------------- |
  | 默认值 | 安装目录下的logs/nginx.pid |
  | 位置   | 全局块                     |

- error_log 配置nginx错误日志存放的路径

  | 语法   | error_log file路径[日志级别]   |
  | ------ | ------------------------------ |
  | 默认值 | 安装目录下的logs/error.log     |
  | 位置   | 全局块、HTTP，server、location |

- include 用来引入其他配置文件，使nginx的配置更加灵活

  | 语法   | include file路径 |
  | ------ | ---------------- |
  | 默认值 | 无               |
  | 位置   | any              |

  在nginx.conf里使用nginx file可以引入其他的配置文件



### events块

- accept_mutex：用来配置nginx网络连接序列化

  | 语法   | accept_mutex on/off |
  | ------ | ------------------- |
  | 默认值 | on                  |
  | 位置   | events块            |

  这个配置主要是用来解决‘惊群’问题，客户端发来一个请求连接，nginx后台是以多进程的工作模式（多个worker进程），多个进程会同时被唤醒，但始终是有一个获取连接，如果唤醒的进程太多，就会影响到Nginx的性能。若开启网络连接序列化，将对这多个进程进行序列化，一个一个按顺序唤醒和就收，防止多个进程对连接的争抢。

- multi_accept：是否允许同时接受多个网络连接

  | 语法   | multi_accept on/off |
  | ------ | ------------------- |
  | 默认值 | off                 |
  | 位置   | events块            |

- worker_connections：配置单个worker进程的最大连接数

  | 语法   | worker_connections number |
  | ------ | ------------------------- |
  | 默认值 | 1024                      |
  | 位置   | events块                  |

- use：设置服务器选择哪种事件驱动来处理网络消息

  | 语法   | use method   |
  | ------ | ------------ |
  | 默认值 | 根据系统指定 |
  | 位置   | events块     |

  这个选择事件处理模型是nginx优化的重要内容
  method的可选值：select、poll、epoll、kqueue
  linux内核在2.6以上，才能使用epoll



### HTTP块

#### 定义MIME-Type

MIME-Type是网络资源的媒体类型。nginx作为web服务器，也需要能够识别前端请求的资源类型

在Nginx的配置文件中的两行默认配置

```
include mime.types;	//mime.types记录的是mimt类型与相关类型文件的文件后缀名的关系
default_type application/octet-stream
```

- default_type：用来设置nginx响应前端请求的默认mime类型

  | 语法   | default_type type      |
  | ------ | ---------------------- |
  | 默认值 | text/plain             |
  | 位置   | http、server、location |



#### 自定义服务日志

Nginx中的日志类型分为access.log和error.log日志
access.log：记录用户的所有访问请求
error.log：记录nginx运行的错误信息
nginx服务器支持对日志的格式，大小，输出等进行设置，需要使用以下两个指令

1. access_log 设置用户访问日志的相关数据

   | 语法   | access_log path路径[format输出格式]\[buffer=size文件大小] |
   | ------ | --------------------------------------------------------- |
   | 默认值 | access_log  logs/access.log combined                      |
   | 位置   | http、server、location                                    |

2. log_format  设置日志的输出格式

   | 语法   | log_format name [escap=default\|json\|none...] string...; |
   | ------ | --------------------------------------------------------- |
   | 默认值 | log_format combined '...'                                 |
   | 位置   | http                                                      |



#### 其他配置指令

1. sendfile：设置nginx服务器是否使用sendfile()传输文件，该属性可以大大提高nginx处理静态资源的性能

   | 语法   | sendfile on/off        |
   | ------ | ---------------------- |
   | 默认值 | off                    |
   | 位置   | http、server、location |

2. keeplive_timeout：设置长连接的超时时间

   - HTTP是一种无状态协议，客户端向服务端发送一个TCP请求，服务端响应完成后断开连接
   - 如果客户端向服务端发送了多个请求，每个请求都要重新建立一次连接，效率和性能较低，使用keeplive模式，可以告诉服务端，完成一个请求后，保持这个tcp请求打开状态，若列收到这个客户端的其他请求，就利用这个未关闭的连接，不需要再次建立一个新的连接，提升效率，但是这个连接也不能一直保持下去，会严重影响服务端的性能，所以就要设置超时时间。

   | 语法   | keeplive_timeout time  |
   | ------ | ---------------------- |
   | 默认值 | 75秒                   |
   | 位置   | http、server、location |

3. keeplive_requests：设置一个连接使用的最大次数

   | 语法   | keeplive_requests number |
   | ------ | ------------------------ |
   | 默认值 | 100                      |
   | 位置   | http、server、location   |

   

### 简述-server块

- listen：监听的端口
- server_name：服务名，可以是localhost 可以是IP或者域名



### 简述-location块























































